提供makefile文件编译
编译指令为
flex lexical.l
bison -d syntax.y
gcc main.c syntax.tab.c sema.c hashtable.c irfile.c asm.c -lfl -ly -o parser
新增文件asm.h, asm.c