本次实验新增文件 irfile.h, irfile.c，用于将语法树翻译为三地址码

编译命令：  flex lexical.l
            bison -d syntax.y
            gcc main.c syntax.tab.c sema.c hashtable.c irfile.c -lfl -ly -o parser

提供makefile文件： make
                  make clean

默认输出文件： output.ir
